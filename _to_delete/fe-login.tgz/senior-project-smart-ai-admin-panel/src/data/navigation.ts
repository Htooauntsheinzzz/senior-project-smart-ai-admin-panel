import { Activity, BarChart3, BookOpen, Bot, Building2, CalendarDays, GraduationCap, LayoutDashboard, Megaphone, Settings, Users, type LucideIcon } from 'lucide-react'

type Destination = { id: string; label: string; to?: string }
export type NavigationItem = Destination & { icon: LucideIcon; children?: Destination[] }

export const navigation: NavigationItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, to: '/admin/dashboard' },
  { id: 'users', label: 'User Management', icon: Users, to: '/admin/users' },
  { id: 'students', label: 'Students', icon: GraduationCap, to: '/admin/students' },
  { id: 'academic', label: 'Academic Management', icon: BookOpen, children: [
    { id: 'semesters', label: 'Semester', to: '/admin/semesters' },
    { id: 'faculties', label: 'Faculty', to: '/admin/faculties' },
    { id: 'departments', label: 'Department', to: '/admin/departments' },
    { id: 'lectures', label: 'Lectures', to: '/admin/lectures' },
    { id: 'programs', label: 'Program', to: '/admin/programs' },
    { id: 'courses', label: 'Courses', to: '/admin/courses' },
    { id: 'sections', label: 'Course Sections', to: '/admin/sections' },
    { id: 'enrollments', label: 'Enrollments', to: '/admin/enrollments' },
  ] },
  { id: 'timetable', label: 'Timetable', icon: CalendarDays, children: [
    { id: 'class-timetable', label: 'Class Timetable', to: '/admin/timetable' },
    { id: 'academic-terms', label: 'Academic Terms', to: '/admin/academic-terms' },
  ] },
  { id: 'activities', label: 'Academic Activities', icon: Activity, children: [
    { id: 'assignments', label: 'Assignments', to: '/admin/assignments' },
    { id: 'exams', label: 'Exams', to: '/admin/exams' },
  ] },
  { id: 'campus', label: 'Campus Management', icon: Building2, children: [
    { id: 'setup', label: 'Campus Setup', to: '/admin/campus-setup' },
    { id: 'map', label: 'Campus Map', to: '/admin/campus-map' },
    { id: 'buildings', label: 'Buildings', to: '/admin/buildings' },
    { id: 'rooms', label: 'Rooms', to: '/admin/rooms' },
    { id: 'places', label: 'Campus Places', to: '/admin/campus-places' },
    { id: 'routes', label: 'Navigation Routes', to: '/admin/navigation-routes' },
  ] },
  { id: 'ai', label: 'AI Management', icon: Bot, children: [
    { id: 'knowledge', label: 'AI Knowledge Base', to: '/admin/ai-knowledge-base' },
    { id: 'test-knowledge', label: 'Test AI Knowledge', to: '/admin/test-ai-knowledge' },
    { id: 'assistant', label: 'AI Assistant', to: '/admin/ai-assistant' },
    { id: 'history', label: 'Chat History', to: '/admin/chat-history' },
    { id: 'feedback', label: 'AI Feedback', to: '/admin/ai-feedback' },
  ] },
  { id: 'communication', label: 'Communication', icon: Megaphone, children: [
    { id: 'announcements', label: 'Announcements', to: '/admin/announcements' },
    { id: 'notifications', label: 'Notifications', to: '/admin/notifications' },
    { id: 'reminders', label: 'Smart Reminders', to: '/admin/reminders' },
  ] },
  { id: 'reports', label: 'Reports & Analytics', icon: BarChart3, to: '/admin/reports' },
  { id: 'settings', label: 'Settings', icon: Settings, children: [
    { id: 'university', label: 'University Settings', to: '/admin/university-settings' },
    { id: 'audit', label: 'Audit Logs', to: '/admin/audit-logs' },
  ] },
]
