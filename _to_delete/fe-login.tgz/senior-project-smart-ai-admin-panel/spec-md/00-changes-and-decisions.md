# 00 - Changes and Decisions

## Purpose

This document records implementation changes and technical decisions for the Smart AI Admin Web frontend.

## 2026-11-13 - Login page: security indicators and staff-only notice removed

- Requested: Hsu asked to remove the bottom of the login card shown in a screenshot: the "SECURE ACCESS" divider with the "256-bit SSL / Admin Only / Verified" dots, and the yellow "Staff only. Students, use the SMART AI mobile app." notice.
- Change: `LoginForm.jsx` now ends after the Sign In button (the card keeps its own padding); `LoginPage.jsx` goes straight from the card to the footer (`mt-7`). `SecurityIndicators.jsx` and `StaffOnlyNotice.jsx` had no other users and were moved out of `src/` into `_to_delete/` (the sandbox cannot delete files). No tests referred to them. Spec `03-loginscreen.md` sections 27–29 marked as removed.
- Frontend only. Uncommitted.

## 2026-11-13 - Chat History: 3 conversations per page

- Requested: the Chat History table should show 3 conversations per view, the rest through the Next button.
- Change: `ChatHistoryContent.tsx` uses its own `PAGE_SIZE = 3` for the request (`size=3`), the `No.` numbers and the pager ("Showing 1–3 of 4 conversations"). The other tables keep 10 rows (`TABLE_PAGE_SIZE`); AI Feedback is unchanged. The export still contains every conversation that matches the filters.
- Spec `43-api-implementation-chat-history.md` updated. Checks: `tsc --noEmit`, `eslint .`, `node --test tests/*.test.cjs` (100). Uncommitted.

## 2026-11-13 - AI answers read like a normal chat reply (backend, admin and mobile)

- Requested: in the first live test the answer was correct but showed Markdown and a reference ("According to **academic-calendar-2** (Academic year 2026-2027, Page 2) ... * **March 1 – 5, 2027**"). Hsu wants a normal reply like Claude, Gemini or ChatGPT give in a chat, without the reference in the text, for the admin panel and for the mobile chat.
- Fix (backend only, decision D85): both assistants are told to start with the answer in natural sentences, to write plain text without Markdown and not to mention document names, pages or sections. A new cleaner (`AssistantAnswerText.plain`) removes any Markdown the model still writes before the answer is returned and stored.
- Admin panel: no code change. AI Assistant and Test AI Knowledge already print the answer as plain text, and the sources stay where they were (chips under a chat answer, Supporting Sources in the test). Mobile app: no code change either, it prints the answer as plain text.
- Trade-off: an answer no longer names its document. In the admin panel the sources are still visible next to it; the mobile app does not show sources yet.
- Checks: new backend `AssistantAnswerTextTests` (3); full backend suite 1486 tests with only the two known unwritable-storage failures of the cloud container. No live Gemini run, so the wording of real answers has to be judged after a restart.
- To use it: rebuild and restart the backend. Answers saved before the change keep their old text in Chat History.

## 2026-11-13 - AI Management: AI Assistant, Test AI Knowledge, Chat History and AI Feedback connected (frontend + backend)

- Requested: the four screens showed "API unavailable". Check whether the backend or the frontend is missing, implement what is missing, and write the specs first. The administrator must be able to test the AI assistant chat; the student side works and must not change.
- Found: both sides were missing. The backend had only the student chat (`POST /api/v1/student/assistant/chat`), the student's own conversation endpoints and the admin semantic search (`POST /api/v1/admin/knowledge/search`). The four components were static placeholders.
- Specs: backend `backend/seniorproject/spec-md/59-admin-ai-management-api.md`; frontend `41-api-implementation-ai-assistant.md`, `42-api-implementation-test-ai-knowledge.md`, `43-api-implementation-chat-history.md`, `44-api-implementation-ai-feedback.md`.
- Backend (explicitly requested; decision D84 in the backend log), all under `/api/v1/admin/assistant` for `SUPER_ADMIN`, `ADMIN` and `ACADEMIC_ADMIN`:
  - `POST /chat` and `POST /knowledge-test`: search the Ready knowledge documents, then one model request with the passages in the prompt. The model gets no tools, so an admin chat cannot read student records. Nothing is stored.
  - `GET /conversations`, `/conversations/{id}`, `/conversations/export`: read-only view of the students' stored conversations (spec 58 tables) with search, date filter, paging and CSV.
  - `GET /feedback`, `/feedback/statistics`, `/feedback/{id}`, `/feedback/export` and `PATCH /feedback/{id}/review`, on the new table `assistant_message_feedback` (Flyway V56).
- Student side: the existing student APIs are unchanged. Two additions were needed for feedback to exist at all: a new endpoint `PUT /api/v1/student/assistant/conversations/{conversationId}/feedback` (a student rates one of their own answers) and, when a student deletes a conversation, its feedback rows are deleted first (the schema has no cascading foreign keys). The mobile app does not call the rating endpoint yet, so AI Feedback stays empty until it does (or until a rating is sent with Postman).
- Decisions:
  - The admin chat is a test chat, not a second student chat: it answers from documents only and keeps its conversation in the browser (the earlier turns are sent with each message, at most 20). It is not written to Chat History, so test questions never mix with student data.
  - Test AI Knowledge does not call the model when no passage matches. It says so instead, because an answer from general knowledge would hide a gap in the knowledge base.
  - Chat History is read-only for administrators. Reading a transcript is logged on the backend with the administrator's id and the conversation id, never with message text.
  - Date filters are local days in the browser and instants on the server: From is sent as local midnight, To as the start of the next local day, so the To day is included.
  - Model, student and document text is rendered as plain text. Backend error messages are mapped to fixed copy by code.
- Frontend: `src/types/aiAssistant.ts`, `src/utils/aiAssistant.ts`, `src/services/aiAssistantService.ts`, `src/components/ai/AssistantUi.tsx` (shared pieces) and the four rewritten components. The layouts stay as they were; both tables got the `No.` column and 10 rows per page with `TablePagination`; export and review show the green toast. `/admin/chat-history?conversation=<id>` opens one transcript (used by the link in the feedback review modal).
- Checks: `tsc --noEmit`, `eslint .`, `node --test tests/*.test.cjs` (100, new `tests/ai-management.test.cjs` with 9), `vite build`, and a Playwright run of all four screens with mocked responses (chat with sources, test with passages, history with transcript, feedback with review and toast, no console errors). Backend: the two new test classes pass (9 tests) and the full suite ran 1483 tests with 2 failures, both the known unwritable-storage tests that fail only in the cloud container (it runs as root). No live Gemini run was made for the new endpoints.
- To use it: restart the backend so Flyway applies V56. Changes are uncommitted.

## 2026-11-13 - Knowledge Base: Gemini embedding size matches the 768-dimension vector column (backend)

- Problem: `gemini-embedding-001` returns 3072 numbers per vector by default, but `academic_document_chunks.embedding` is `vector(768)` (V51) with an HNSW cosine index. If the size differs, the EMBED stage fails with `EMBEDDING_DIMENSION_MISMATCH` and the document ends as Failed instead of Ready.
- Checked: the backend already asks the provider for 768 numbers (`dimensions: 768` in the OpenAI-compatible `POST {base-url}/embeddings` body, `AI_EMBEDDING_SEND_DIMENSIONS=true` by default) and L2-normalizes every vector itself, which Google requires for `gemini-embedding-001` below 3072. Google's OpenAI-compatibility page does not document the `dimensions` field for embeddings, so it could be ignored.
- Decision: keep the column at 768 (one of Google's recommended sizes; pgvector HNSW/IVFFlat indexes allow at most 2000 dimensions, so 3072 cannot be indexed) and make the client tolerant instead of adding a migration. No re-embedding or schema change is needed.
- Backend (explicitly requested): new setting `app.knowledge.embedding.truncate-longer-vectors` (`AI_EMBEDDING_TRUNCATE_LONGER_VECTORS`, default `true`, added to `application.properties`, `compose.yaml` and `.env.example`). When the provider returns more numbers than `AI_EMBEDDING_DIMENSIONS`, `OpenAiCompatibleEmbeddingClient` keeps the first 768 and re-normalizes (the Matryoshka reduction Gemini itself applies for `output_dimensionality`). A shorter vector still fails with `EMBEDDING_DIMENSION_MISMATCH`. Set the flag to `false` for a model that is not Matryoshka-trained.
- `AI_EMBEDDING_DIMENSIONS` stays validated to 768 because it must equal the column; a different size needs a new migration plus a full re-embedding.
- Live test (same day, with Hsu's key): Gemini does honour `dimensions: 768` (and returns 3072 without it), but it leaves `"index"` out of the first entry of `data` (0 is omitted). The parser required an index on every entry, so every Gemini reply failed with `EMBEDDING_INVALID_RESPONSE`; this was the real blocker. Fix: a missing index now means the entry's position in the array; a present index must still be a valid, unused integer, so duplicates and gaps are still rejected.
- Tests: `OpenAiCompatibleEmbeddingClientTests` (9) adds the missing-index reply shape, a 3072 → 768 truncation case and a strict-mode mismatch case. `LiveEmbeddingCheck` passes against the real Gemini endpoint through the backend client (3 texts in one request, 768 numbers each, normalized). The wider knowledge test run passed 169 of 171 before the index fix; the two failures are unwritable-storage tests, most likely because the test container runs as root. No `.env` change is needed. Restart the backend and reprocess Failed documents. Changes are uncommitted.

## 2026-11-12 - Tables: 10 rows per page everywhere

- Requested: every table list should show only 10 rows per view, with Next/Previous for the rest. Before, Courses, Faculties, Departments, Programs, Lecturers, Course Sections, Campus Places, Campus Setup, Navigation routes and destinations, and Schedule Conflicts showed every row on one page; Admin Users and Buildings paged by 8 and the Timetable list by 20.
- Shared pieces: `TABLE_PAGE_SIZE = 10`, `paginate()` and `pageSummary()` in `src/utils/pagination.ts` (`utils/academicTerms.ts` re-exports `paginate`); `usePagedRows(rows, resetKey)` in `src/hooks/usePagedRows.ts` pages a fully loaded list on the client and goes back to page 1 when the search/filters change; `src/components/ui/TablePagination.tsx` wraps the existing `ui/Pagination` with the footer "Showing 11–20 of 34 courses" (plus "(N in total)" when filters hide rows and a server total is known).
- Client-paged (lists already load the whole directory): Courses, Faculties, Departments, Programs, Lecturers, Course Sections (enrolled/capacity line kept, still for all filtered rows), Campus Places (cards and table), Campus Setup (each tab), Navigation Route List and Destinations (the graph still draws every route), Schedule Conflicts. Row "No." values continue across pages (11, 12, …). Export on Courses still exports every filtered row.
- Server-paged: Admin Users and Buildings now request `size=10` (Admin Users' "Showing a–b" used a hard-coded 8, now `TABLE_PAGE_SIZE`); Timetable list `LIST_PAGE_SIZE` 20 → 10. Students, Enrollments, Rooms, Semesters, Academic Terms and Knowledge Base already used 10.
- Not changed: Announcements, Notifications, Exams, Assignments, Audit Logs, AI Feedback and Chat History have no data API yet, so their tables stay empty with the disabled pager.
- Lists are still sorted oldest first (`id,asc`), so a newly added record appears on the last page.
- Checks: `tsc --noEmit`, `eslint .`, `node --test tests/*.test.cjs` (91, new `tests/pagination.test.cjs`), `vite build`, and a Playwright run on Courses with 23 mocked courses (10 / 10 / 3 rows, "Showing 21–23 of 23 courses"). Changes are uncommitted.

## 2026-11-12 - Courses: new course now shows in the list after saving

- Problem: after Save Course (or Update Course) the app returned to the Courses list, but the new course was missing until a full page reload, even though the message said "Refreshing server data."
- Cause: `CourseCatalog` is the layout route for both `/admin/courses` and `/admin/courses/new`, so it stays mounted. Its list, summary and lookup requests only rerun when `filters` or `attempt` change, and `AddCourseContent` navigated back without changing either, so the old list stayed on screen. The backend was checked read-only and is fine: `POST /courses` saves, and `GET /courses` (`sort=id,asc`, all pages loaded) returns the new row.
- Fix: `AddCourseContent.submit` calls the catalog's `retry()` after a successful create or update, before navigating back. That bumps `attempt`, so the list, summary cards and lookups reload. Delete already did this.
- Checks: `tsc --noEmit`, `eslint src/components/courses` and `node --test tests/courses.test.cjs` (7) pass. Changes are uncommitted.

## 2026-11-12 - Campus: full-precision latitude/longitude

- Problem: in Add Campus, valid coordinates copied from Google Maps (`13.964438098079592`, `100.5866727383530`) showed "Latitude must be between -90 and 90" / "Longitude must be between -180 and 180". The frontend pattern allowed at most 10 decimals, and the backend allowed only 7 (`NUMERIC(10,7)` columns plus a scale check in `CampusWriteSupport.coordinates`), so the values could not be saved even past the form.
- Decision: store coordinates as typed, up to **15 decimal places**, rather than rounding them. Range checks (-90..90, -180..180) are unchanged.
- Frontend (`src/utils/campusApi.ts`): one shared `coordinateError` for campus (site) and navigation node forms accepts up to 15 decimals. A bad format now says "Enter latitude as a number with at most 15 decimal places." and only a real out-of-range value says "must be between". Buildings and places get coordinates through linked navigation nodes, so they are covered too.
- Backend (explicitly requested, the fix needs it): migration `V55__widen_campus_coordinate_precision.sql` widens `campus_sites.center_latitude/center_longitude`, `campus_nav_nodes.latitude/longitude` and `campus_nav_edge_points.latitude/longitude` to `NUMERIC(18,15)` (existing values kept); entity `@Column` precision/scale updated; `CampusWriteSupport.COORDINATE_SCALE = 15`. Responses now return the stored value, e.g. `100.586672738353000`.
- Tests: frontend `node --test` (88) adds full-precision and error-message cases; backend `CampusAdminIntegrationTests` now creates a node with the exact values above and rejects 16 decimals. All 71 `Campus*` backend tests pass on PostgreSQL (Testcontainers). Restart the backend so Flyway applies V55. Changes are uncommitted.

## 2026-11-12 - Programs: "General Education" degree level

- Requested: add **General Education** to the Degree Level dropdown of the Program create/edit drawer.
- Added `{ id: 'ge', name: 'General Education' }` to `degrees` in `src/data/programs.ts` (teal badge `#CCFBF1` / `#0F766E`, a colour not used by the other levels). The same list feeds the drawer select, the Degree Level filter, the table badge and the details modal, so all of them pick it up.
- Backend unchanged: `degreeLevel` is a free-text `VARCHAR(100)` (`@NotBlank @Size(max = 100)`, no enum or check constraint), so saving "General Education" already works end to end.
- Fix found on the way: the Degree Level filter on the Programs list sent the option id (for example `beng`) as `degreeLevel`, while the API matches the stored name, so filtering by any degree returned nothing. `getProgramDirectory` now maps the id to the degree name before calling `GET /programs`.
- Checks: `tsc --noEmit`, `eslint` on the changed files and `node --test tests/*.test.cjs` (88 tests) pass. Changes are uncommitted.

## 2026-11-12 - Faculty codes accept lowercase letters and spaces (frontend + backend)

- Requested: creating a faculty with the code `Engineering-Technology` was rejected with "Use at most 30 uppercase letters, numbers, or hyphens." Hsu asked for the fix in both frontend and backend (second explicit backend exception after the section room/schedule removal).
- Rule now: 1 to 30 letters (upper or lower case), numbers, spaces, or hyphens; outer whitespace is trimmed and the code is otherwise stored exactly as typed (no uppercasing, inner spaces kept). Frontend `validateFacultyForm` uses `^[A-Za-z0-9 -]+$` and the hint "Use at most 30 letters, numbers, spaces, or hyphens."; backend `FacultyCreateRequest`/`FacultyUpdateRequest` use the same `@Pattern`. Spaces were added in a follow-up: Hsu typed `Engineering -Technology` and did not want the "no spaces" error. Faculty codes are only displayed elsewhere (AI tool results, academic queries), never used in URLs or matching, so spaces are safe.
- Uniqueness is case-insensitive so `FAC-ENG` and `fac-eng` cannot coexist: `FacultyRepository.existsByFacultyCodeIgnoreCase` / `existsByFacultyCodeIgnoreCaseAndIdNot`, and Flyway `V54__faculty_code_case_insensitive_unique.sql` replaces the `uk_faculties_faculty_code` constraint with a unique index of the same name on `LOWER(faculty_code)` (the same name keeps the race-condition mapping to `FACULTY_CODE_ALREADY_EXISTS`). Existing data was uppercase only, so the index cannot hit duplicates.
- Department and program codes still require uppercase; they were not part of the request.
- Tests: `tests/faculties.test.cjs` accepts `Engineering-Technology` and `Engineering -Technology` and rejects underscores; `FacultyIntegrationTests` now rejects `FAC_IT`, rejects `fac-it` as a duplicate of `FAC-IT`, and creates `Engineering -Technology`. Frontend tests pass; the backend could not be compiled or run here (Maven could not download, the suite needs Docker). Changes are uncommitted.

## 2026-11-12 - AI Knowledge Base screen: design-to-code from Figma and connected to the real knowledge API

- Requested: build the AI management screen exactly from Figma and check whether the backend is ready for document upload. The Figma frame "AI Management " (`168:1864`) is the AI Knowledge Base; its content node `168:2100` "AIKnowledgeBaseScreen" was implemented with the figma-design-to-code workflow. The page at `/admin/ai-knowledge-base` (sidebar AI Management › AI Knowledge Base) was a placeholder that said the backend had no knowledge API; that was out of date and was replaced.
- Backend used read-only (`backend/seniorproject/feature/knowledge`, roles SUPER_ADMIN/ADMIN/ACADEMIC_ADMIN): `GET /knowledge/documents` (plain page; `search`, `categoryId`, `academicYear`, `status`, `isActive`, `sort`), `GET /knowledge/documents/statistics` (`totalDocuments`, `readyDocuments`, `processingDocuments`, `failedDocuments`), `POST /knowledge/documents/upload` (multipart: `title`, `categoryId`, `academicYearLabel` `YYYY-YYYY`, `description`, `file`; any other field is 400), `GET/PUT/DELETE /knowledge/documents/{id}` (PUT replaces all metadata; DELETE is a soft delete), `PATCH /{id}/activate|archive`, `POST /{id}/files` (new file revision), `GET /{id}/download`, `GET /{id}/processing`, `POST /{id}/reprocess` (no body = RESUME, `{mode:"FULL"}`), `GET/POST /knowledge/categories`. Files: PDF, DOCX, TXT, XLSX up to 50 MB; processing status UPLOADED → QUEUED → PROCESSING → CHUNKING → EMBEDDING → READY / FAILED.
- Layout from Figma: header (title, subtitle, Upload Document button with the Figma upload icon), four tinted cards (Total Documents, Ready, Processing, Failed), filter bar (search 240 px, All Categories, All Years, All Statuses, "N documents"), table Document Name (category emoji + title, "⛔ Inactive" below when deactivated), Category chip, Acad. Year (mono, en dash), Type chip, Uploaded By, Date, AI Status badge (✅ Ready, ❌ Failed, Figma spinner icon for Embedding/Chunking/Processing/Queued/Uploaded), Actions ▾. Icons were exported from Figma as SVG (`public/assets/figma/ai-upload.svg`, `ai-status-{embedding,chunking,processing}.svg`).
- Decisions: a **No.** serial column was added in front (project convention, not in the frame). The Figma "Test AI Knowledge" link is not in this frame, so the header only has Upload Document (Test AI Knowledge stays in the sidebar). Category colours/emojis follow the Figma rows by keyword in the category code or name, other categories get a stable palette colour and 📄. The year filter offers next year back to six years ago. Search is debounced 300 ms and sent to the server; the list is paged on the server, 10 per page. While a document is still processing the list and cards refresh every 5 s.
- CRUD follows the Programs pattern: drawer for Upload and Edit details (`KnowledgeDocumentForm`, dirty-close confirmation, upload progress, title prefilled from the file name), modal for Replace file, View details (document + processing counts and last error) and Delete; actions Retry processing (FAILED, RESUME), Reprocess (READY, FULL), Deactivate/Activate, Download; green toast after every change. Edit sends the stored program/department/curriculum scope back so it is not wiped.
- Gap found: no Flyway migration seeds `document_categories`, so on a fresh database there is no category and the upload cannot be sent. The upload drawer therefore has "+ New category" (POST `/knowledge/categories`, code derived from the name). The upload form has no Program/Department/Curriculum scope yet: uploads are university-wide.
- Files: `src/components/ai/KnowledgeBaseContent.tsx`, `src/components/ai/KnowledgeDocumentForm.tsx`, `src/pages/ai/KnowledgeBasePage.jsx`, `src/services/knowledgeService.ts`, `src/utils/knowledgeBase.ts`, `src/types/knowledge.ts`, `tests/knowledge-base.test.cjs`.
- Verification: `tsc --noEmit`, `eslint .`, `node --test tests/*.test.cjs` (88 tests) pass; production build and a screenshot at 1491 px with a mocked API compared against the Figma frame. Changes are uncommitted.

## 2026-11-09 - Course Sections: room and schedule removed, the timetable is the only source of class times (frontend + backend)

- Requested after the Academic Terms page: the free-text **Room** and **Schedule** of a course section duplicated the Timetable feature (spec 40), so they were removed from the frontend and, on explicit request, from the backend including the database and the student/AI APIs. This is the one exception to the frontend-only rule of this repository; it was asked for in writing.
- Frontend (Course Sections): no Room/Schedule fields in the create/edit drawer, no Room/Schedule rows in the details modal (hint: rooms and class times are scheduled on the Class Timetable), the table column "Room / Schedule" became "Academic Term" (label and code, or "Not assigned"); `CourseSection`, `emptySectionDraft`, validation, `sectionPayload` and `mapSection` lost the two fields and `updateSection` sends the full payload. Enrollments: the details modal no longer shows Room/Schedule and `enrollmentService` no longer expects them.
- Backend, course sections: `CourseSectionCreateRequest`/`UpdateRequest`/`Response`/`ListResponse`, `CourseSectionMapper`, `CourseSectionServiceImpl` (search no longer matches room) and the `room` sort field dropped; `CourseSection` entity without the columns; Flyway `V45__drop_course_section_room_and_schedule.sql` drops them. Because `fail-on-unknown-properties` is on, a request that still sends `room` or `schedule` is rejected with 400.
- Backend, student and assistant APIs (Hsu: "it will work with timetable feature using ai assistant"): `EnrollmentResponse` (admin) lost `room`/`schedule`; `StudentAcademicEnrollmentResponse` and `StudentAcademicScheduleResponse` carry `meetings` (the section's PUBLISHED timetable meetings with weekday, times, effective dates, room, building and upcoming exceptions) instead; `/enrollments` therefore loads meetings like `/schedule` and `/courses` do. `AcademicEnrollmentQueryResult`, `AcademicScheduleQueryResult` and `AcademicCourseSectionQueryResult` carry `meetings`, so the AI tools `get_my_enrollments`, `get_my_schedule` and `get_my_course_section` hand the model structured meetings (`dayOfWeek`, `startTime`, `endTime`, `roomNumber`, `buildingName`, ...) and no free text; tool descriptions updated. `SafeAcademicResponseFactoryImpl` renders meetings ("Tuesday 09:00-11:45 (lecture) in room 11-402, Building 11"; "timetable not currently available" when none) and keeps the classroom-unavailable sentence when a section has no published meeting; `GroundedAnswerValidatorImpl` accepts `roomNumber` as room evidence.
- Backend tests: new `PublishedMeetingTestData` (test helper) publishes a meeting in a campus room from the old `room`/`schedule` fixture strings and moves or unpublishes it (`setRoom`), so fixtures keep their data (CS301 SEC-01 Tuesday 09:00-11:45 in 11-402, CSC460 without timetable); integration tests, the step 8 regression dataset and the grounding fixtures were updated to the `meetings` shape. The suite needs Docker (Testcontainers) and could not be executed here; main and test sources were compiled.
- Open: Hsu reported "View details is not work" on Course Sections. With a mocked API the details modal renders (Playwright against the production build) and the backend detail path is unchanged, so the exact error or network response is needed to go further.

## 2026-11-09 - Academic Terms page under the Timetable menu

- Requested after the Timetable delivery: academic terms get their own screen instead of the "Manage Terms" drawer on the Timetable page. The sidebar item **Timetable** is now a group with **Class Timetable** (`/admin/timetable`) and **Academic Terms** (`/admin/academic-terms`); the top-bar section chip treats both paths as Timetable. The `AcademicTermsDrawer` component was removed; the Timetable toolbar button "Manage Terms" and the no-terms banner now link to the new page.
- Backend used read-only, all under `/api/v1/admin/academic-terms`: `GET` (plain page; filters `semesterId`, `status`, `academicYearCode`, `search`; sorts `id`, `startDate`, `endDate`, `status`), `GET /{id}`, `POST` and `PUT /{id}` with `{semesterId, academicYearCode ≤20, academicYearLabel ≤30, startDate, endDate, status?}` (status optional: PLANNED on create, kept on update), `PATCH /{id}/status` with `{status}`, `DELETE /{id}` (409 `ACADEMIC_TERM_IN_USE` while live course sections reference the term; `TIMETABLE_INVALID_DATE_RANGE` when the end date is before the start).
- Page follows the Programs / Campus pattern with the shared `CampusUi` kit: summary cards (Total, Active, Planned, Closed), search plus Semester and Status filters, table with No., Academic Year (label and code), Semester (English with Thai below), Start Date, End Date, Duration, Status and an Actions menu (View details, Edit, Mark active / Close term / Reopen as active, Delete); drawer for create and edit (`AcademicTermForm`, dirty-close confirmation, semester list from `/semesters`), modal for details (`GET /{id}`) and for delete confirmation, green toast after create, update, status change and delete.
- Decision: the complete term list is loaded once (`getAcademicTerms`, all pages) and searched, filtered, counted and paged on the client (10 per page), because a university has only a few terms per academic year and the backend has no term statistics endpoint for the summary cards. Status quick actions use `PATCH /status`; the form still sends the status with `POST`/`PUT` as the backend accepts it.
- Errors: `academicTermError` wraps `timetableError` with term wording (403 → "manage academic terms", `ACADEMIC_TERM_NOT_FOUND` → term deleted elsewhere, `TIMETABLE_INVALID_DATE_RANGE` → End Date field, `SEMESTER_NOT_FOUND` → Semester field, `ACADEMIC_TERM_ALREADY_EXISTS` → Academic Year Code field).
- Files: `src/pages/timetable/AcademicTermsPage.jsx`, `src/components/timetable/AcademicTermsContent.tsx`, `src/components/timetable/AcademicTermForm.tsx`, `src/utils/academicTerms.ts`, `timetableService.getAcademicTermById` / `setAcademicTermStatus`, `src/data/navigation.ts`, `TopNav.tsx`, `AppRoutes.jsx`; `TimetableToolbar.tsx` and `TimetableContent.tsx` link instead of opening a drawer. Tests: `tests/academic-terms.test.cjs` (filtering, summary, pagination, duration, status actions, error mapping, detail and status endpoints).
- Course Sections drawer follow-up (same day): the Academic Term select was disabled until a semester was chosen and empty when that semester had no term, which read as broken. It is now always enabled and lists every term labelled with its semester; choosing a term fills in the semester, changing the semester drops a term of another semester (`sectionTermOptions`, `applySectionTermChange` in `utils/sectionApi.ts`, tested in `tests/sections.test.cjs`). The create and update requests already carried `academicTermId` (backend `CourseSectionCreateRequest` / `CourseSectionUpdateRequest` accept it as optional); only the selection UX changed.
- Verification: `tsc --noEmit`, `eslint .` and `node --test tests/*.test.cjs` (78 tests) pass; production build and screenshots of the new page with a mocked API in a clean Linux container. Changes are uncommitted on `dev_shein`.

## 2026-11-09 - Admin Timetable: design-to-code and API implementation (spec 40)

- Frontend only; backend `TimetableController`, `AcademicTermController` and their DTOs were read, not changed. Design taken from Figma file `FQhq9uVri66RJpADxECMtm` with the figma-design-to-code workflow: screen `34:3999`, header/view switch/tabs/filters/legend `34:4266`, weekly calendar `34:4391`, Add Class Schedule modal `193:973`, class details drawer `193:3056`. The old local-demo timetable (`src/data/timetable.ts`, `TimetableCalendar`, `ScheduleForm`, `AddClassScheduleModal`) was deleted; the route `/admin/timetable` keeps its place in the sidebar.
- Endpoints used, all under `/api/v1/admin/timetable`: `GET /calendar?weekStart&academicTermId&facultyId&departmentId&courseId` returns `{weekStart, weekEnd, timezone, events[]}`; `GET /meetings` (plain page, size 20, repeated `sort` params, default `dayOfWeek,asc` + `startTime,asc`); `POST /meetings` creates a DRAFT with `{courseSectionId, roomId, meetingType, dayOfWeek 1-7, startTime, endTime, effectiveFrom, effectiveTo, notes}`; `PUT /meetings/{id}` takes the slot only, so Course and Section are read-only in Edit; `POST /meetings/{id}/publish`, `POST /meetings/{id}/cancel`, `DELETE /meetings/{id}`; `GET /conflicts` (PUBLISHED only, `{total, conflicts}`); `POST /conflicts/check` advisory; `GET /filter-options` for the faculty/department/course/building/room cascades. Academic terms use `/api/v1/admin/academic-terms` CRUD. Responses are validated (page/total mismatch, duplicate occurrences) before use.
- Time semantics: `startsAt`/`endsAt` carry the Asia/Bangkok offset and are rendered as wall-clock time from the string, never converted to the browser zone; the week header shows the `timezone` returned by the backend. Overlapping blocks of one day are laid out in lanes; the visible hour range starts at 08:00-18:00 and widens to cover events; a 10 px top padding keeps the first time label visible under the sticky day header.
- Academic terms are the scheduling key (a course section without `academicTermId` cannot be scheduled: `ACADEMIC_TERM_NOT_FOUND`). Nothing seeds terms and no screen managed them, so the Timetable page has a "Manage Terms" drawer (list/create/edit/delete, semester lookup via `/semesters`) and the Course Sections drawer gained an "Academic Term" field. The backend PUT for sections clears the term when `academicTermId` is omitted, which the old form did silently; the form now always sends it.
- Figma's Semester and Academic Year filters map to academic terms: Semester = the distinct semesters of the existing terms, Academic Year = the term (label disambiguated with the semester when repeated); the server is filtered with `academicTermId` only. The first ACTIVE term (else the term covering today, else the latest) is selected on load and the calendar jumps to the Monday of today or of the term start. Lecturer, Semester and Academic Year in the Add/Edit modal are read-only and derived from the chosen section, because the backend accepts `courseSectionId` only.
- Extensions beyond the Figma frames, required by the backend or by spec 40: Class Type (LECTURE/LAB/TUTORIAL), Effective From/To (prefilled from the section's term, bounded by it) and Notes in the modal; the List view (No., sortable Course Code/Day/Start/Room/Lecturer/Status, Semester, Academic Year, row actions); the Schedule Conflicts tab as a table with View/Edit per schedule and a count badge; the Edit modal; a status card in the details drawer with Publish, Cancel series (confirm modal) and Delete (confirm modal); the week navigator (previous/next/This week); Draft, Moved and Cancelled markers on calendar blocks.
- Conflict pre-check: `conflicts/check` runs before create and update and its failure is ignored (advisory). If it reports conflicts, a warning lists them; "Save draft anyway" is offered for new schedules and for edits of DRAFT meetings; edits of PUBLISHED meetings stay blocked until the slot changes (the backend would answer 409 anyway).
- Conflicts tab: the backend has no `courseId` filter on `/conflicts`, so the Course filter is ignored there and the tab says so; conflicts cover PUBLISHED meetings only, drafts are checked at save time.
- Conventions: No. serial column instead of ids; green auto-dismissing toast on create, update, publish, cancel and delete; details in a drawer and create/edit in a modal exactly as the Figma frames show (this differs from the Programs pattern on purpose). Error codes are mapped to fields and copy in `timetableError` (e.g. `COURSE_SECTION_NOT_FOUND`, `ROOM_NOT_FOUND`, `TIMETABLE_CONFLICT`, `ACADEMIC_TERM_ALREADY_EXISTS`).
- Assets: downloads from figma.com return 403 from both environments, so lucide-react icons and the existing `/assets/figma/faculty-plus.svg`, `faculty-check.svg`, `department-filter-arrow.svg`, `department-select-arrow.svg` are used in the icon slots.
- Roles: the backend lets SUPER_ADMIN, ADMIN and ACADEMIC_ADMIN manage the timetable; the frontend does not gate by role and shows the 403 message when the server refuses.
- Files: `src/types/timetable.ts`, `src/services/timetableService.ts`, `src/utils/timetable.ts`, `src/components/timetable/{TimetableContent,TimetableToolbar,TimetableFilters,WeeklyCalendar,TimetableList,ScheduleConflicts,ScheduleFormModal,ClassDetailsDrawer,AcademicTermsDrawer}.tsx`; `CampusTable` headers accept `aria-sort` objects; `src/utils/courseSections.ts` and the sections drawer carry `academicTermId`. Tests: `tests/timetable-api.test.cjs` (params, payloads, sort, pagination, conflicts, terms, error mapping) and `tests/timetable-utils.test.cjs` (lanes, geometry, week/time helpers, default term, validation, filter cascades).
- Verification: `tsc --noEmit`, `eslint .` and `node --test tests/*.test.cjs` (73 tests) pass; `vite build` and Playwright screenshots of calendar, list, conflicts, drawer, modal, terms drawer and a 390 px layout with a mocked API passed in a clean Linux container with no console errors. The build cannot run in the Mac sandbox used for the session (missing `@rolldown/binding-linux-arm64-gnu`), so `npm run build` should be run on macOS before release. Changes are uncommitted on `dev_shein`.
- Known limits: no bulk publish; `/timetable/statistics` is not surfaced (not in the design); the meetings list is capped at the backend page size; terms must exist and be assigned to sections before any class can be scheduled.

## 2026-10-13 - Semester reimplementation against the current backend (spec 36)

- Frontend only; backend read, not changed. The backend now requires `academicYear` (Integer 2000–2100) on create and update (Flyway V20), so the previous names-only form was rejected with 400. Requests now send exactly `{ academicYear, semesterNameTh, semesterNameEn }`.
- Spec 36 mentions a `status` field (ACTIVE); the backend has no semester status, so no status field, badge or filter was added.
- List uses server pagination (10 per page, `sort=academicYear,desc`), backend `search` (Thai/English name) and `academicYear` filter. Response is the plain page object. Table shows No., Semester Name (EN with TH below), Academic Year, Created, Last Updated, Actions.
- Removed the client-side reference preflight before delete: it sent `semesterId` to `/students`, which that endpoint rejects with 400, so every delete failed. Delete now calls only `DELETE /semesters/{id}` (soft delete, 204) after the confirm modal.
- Follows the Lecturers pattern: drawer for add/edit (`?add=1`), modal for details and delete confirm, green auto-dismissing toast on create/update/delete. SEMESTER_ALREADY_EXISTS (409) marks year and both names.
- Courses and Course Sections still use the semester lookup in `courseService.getSemesters`, unchanged.

## 2026-10-07 - Frontend-only correction: existing APIs only

- User explicitly prohibited backend code changes and selected **Existing APIs only** after the missing API capabilities were explained. This supersedes the full-stack entry below.
- Reverted every backend source change made for the prior iteration, removed the added migration source/session service/tests, and rebuilt/redeployed the original backend. Its original semester and lecturer contracts are authoritative again. No frontend code calls `/teaching-sessions` or submits semester metadata.
- Kept the requested sidebar order. Semester now implements real English/Thai-name CRUD with required/max-length validation, search, total count, fresh details, confirmation and failure handling. Existing Course/Section/Student APIs are checked before deletion; known references or failed checks block the DELETE request. This client preflight is not an atomic server guarantee and cannot see hidden historical references.
- Lectures explicitly explains that scheduled-session APIs are unavailable and links to real Course Sections. Semester code/year/dates/status, active/upcoming totals, and scheduled-session CRUD remain blocked by the unchanged API, as accepted by the user. Original Timetable route/functionality restored.
- **Database restoration caveat:** the prior deployment had already applied V19. Its additive database objects/history were retained to avoid deleting possible data. Original backend startup succeeds; Flyway reports database version 19 ahead of source version 18. No new migration is required or applied by the current frontend. Source restoration does not mean this previously applied schema was removed.
- Current checks: all 32 frontend tests pass, including supported semester payloads, guarded deletion, failed reference checks, paging and existing academic services. Lint and TypeScript pass. Earlier teaching-session integration tests below describe the reverted implementation only. See `22-semester-and-scheduled-lectures.md` for current scope and limitations.

## 2026-10-06 - Semester and scheduled Lectures modules (superseded)

- Added Semester and Lectures navigation in the requested academic order, retaining existing Faculty, Department, Program, Courses, Course Sections and Enrollments URLs and other sidebar sections.
- Added shared academic directory/forms at `/admin/semesters` and `/admin/lectures`, matching Faculty page styling with search/filter controls, full CRUD, confirmation, loading/error/empty/success states, status badges and summary cards below the table. Reused the central Axios client, AdminLayout, Drawer and Modal.
- This request explicitly includes backend changes. Extended semester DTOs/entity/mapper/service with optional metadata for backwards compatibility and required fields in the new UI. Added case-insensitive unique codes, date validation, reference-aware deletion, and date-change protection for scheduled sessions.
- Existing backend `lectures` are lecturer people, not scheduled classes. Added `/api/v1/admin/teaching-sessions` backed by `teaching_sessions`, referencing Course Sections and deriving academic/lecturer relationships. The `/admin/timetable` route now shares persisted session data and CRUD with Lectures, replacing its local-demo runtime. Room/lecturer/section overlaps are rejected server-side; dated sessions do not duplicate free-text section schedule notes.
- Added Flyway V19 (`V19__semester_details_and_teaching_sessions.sql`) with additive columns/table/indexes/checks and reference guards; preserves existing data and IDs. Legacy semester metadata remains unconfigured until edited. New endpoint follows existing academic-admin permission and full-session requirements; authentication flow/roles/tokens are unchanged.
- Verification: all 32 frontend test cases pass; lint, TypeScript and production build pass. PostgreSQL/Redis Testcontainers reports show 6 TeachingSession, 7 Semester and 8 CourseSection integration tests passing, including authenticated HTTP CRUD, validation, persistence, overlap checks, reference blocking, permissions and regression coverage.
- Implementation details and setup: `spec-md/22-semester-and-scheduled-lectures.md`. No screenshot attachment was available; existing Faculty UI was the design reference. Protected browser visual/keyboard checks remain separate from automated API verification and require normal sign-in.

## 2026-10-06 - Course Sections CRUD API integration

- Connected `/admin/sections` to GET/POST `/course-sections`, GET/PUT/DELETE `/course-sections/{id}`, and GET `/course-sections/summary` through the existing central Axios client. Backend controller and DTOs inspected read-only. No backend source, database, or authentication changes.
- Added service response validation, positive safe-integer identity validation, exact `sectionNumber`/`lectureId`/`semesterId` payload mapping, ACTIVE/CLOSED mapping, and safe error-code feedback. Contract clarification: create capacity is optional; full PUT requires positive capacity. Capacity is bounded to Java Integer maximum; blank room/schedule are explicitly null on PUT so existing values can be cleared.
- List uses debounced server filters, abort/obsolete-response guards, stable `id,asc` paging, and a 20-page/2000-record limit with errors for partial/duplicate/inconsistent results. Full is computed client-side with closed precedence. Summary is global; footer uses global summary total and complete filtered enrolled/capacity sums. Pending or failed counts display unknown values.
- Course/semester lookup uses existing APIs; only active courses are offered for new assignments and fetched edit assignment labels are retained. No lecturer lookup controller exists: lecturer ID is entered directly and backend verifies existence, activity, and faculty/department eligibility. Lecturer filter labels accumulate from loaded server rows, not an exhaustive lecturer directory. Year filter derives explicit four-digit years from semester labels; no calendar conversion or unsupported query parameter. Redundant editable academic-year field is omitted because the backend accepts semester ID only.
- Reused the 480px drawer for create/edit with dirty baseline, pending lock, retained failed input, fresh detail modal, and explicit delete confirmation. Server mutations trigger separate list/summary refreshes while retaining filters. Existing table/card/control styling is reused; visual parity and keyboard checks remain pending authenticated access.
- Verification: three focused test groups in `tests/sections.test.cjs` pass (payloads/PUT clearing/ID guards, pagination/filter bounds, mapping/conflicts/204). `npm run lint`, `npx tsc --noEmit`, production Vite build, and Docker build pass. Build reports the existing large-bundle advisory.
- Deployment: rebuilt `admin-web`, then `docker compose up -d --no-deps admin-web`; container is healthy on port 3000. Browser navigation to `/admin/sections` redirects to `/login`; live authenticated CRUD and protected-screen visual verification remain pending normal sign-in. All changes remain uncommitted.

## 2026-10-06 - Faculties CRUD API integration

- Implemented `17-api-implementation-faculties.md` using the existing `/admin/faculties` screen and 460px drawer. Backend source was inspected read-only; no backend, database, authentication, or API changes were made. Shared academic demo fixtures remain available to their other consumers; Faculties now uses server data exclusively.
- Verified FacultyController: POST/GET `/faculties`, GET/PUT/DELETE `/faculties/{id}`, and GET `/faculties/summary`, relative to the existing `/api/v1/admin` Axios client. Positive numeric IDs are validated; DELETE returns 204 and the backend soft-deletes. SUPER_ADMIN, ADMIN, and ACADEMIC_ADMIN with a full session are accepted by the service.
- Create and update send exactly `facultyCode`, `facultyNameEn`, `facultyNameTh`, and boolean `isActive`. Blank Thai name is serialized as null, per DTO normalization. Code is required, max 30 uppercase letters/digits/hyphens; English name required/max 255; Thai name optional/max 255. No client-only uniqueness check is used against an incomplete or stale catalog. Backend code/name conflicts map to the corresponding fields.
- List is paginated with zero-based page and size 1–100; search matches code and English/Thai names. To retain the no-pagination directory design, read all matching pages using stable `id,asc` order, with a bounded 20-page/2000-record limit. Larger results request a narrower search instead of falsely showing a complete directory. Partial, changing-total, duplicate-ID, and malformed responses fail safely. Search is debounced and old requests are aborted/ignored.
- Summary cards use the unfiltered server summary independently from search results. Read failures retain retry controls and unknown summary values, not demo fallbacks. Department counts are supplied by backend statistics. Important backend limitation: FacultyMapper currently emits studentCount=0; the UI faithfully displays that returned value, not an independently verified student aggregate. No backend fix was attempted.
- Existing drawer now awaits POST/PUT, preserves failed form input, locks duplicate submissions, uses a fetched edit baseline, and retains dirty-close confirmation. Editing reserves the same desktop drawer space. Row actions fetch detail, allow edit, and require explicit deletion confirmation. Successful mutations close their UI and trigger separate list/summary refreshes; a failed refresh does not invite repeated mutation.
- Four automated test groups in `tests/faculties.test.cjs` pass, covering exact payload/Thai/false/null mapping, validation/errors, complete-page search and partial-response rejection, URLs, ID validation, summary, and 204 handling. Lint, TypeScript, production build, and Docker build pass. Recreated only `admin-web` at localhost:3000. Authenticated browser/CRUD and rendered visual checks remain pending; the Review app tab is at login.

## 2026-10-06 - Admin User CRUD API integration

- Followed `16-api-implmentation-adminusers.md`, extending the API integration already present in the clean checkout. Preserved the existing table, form cards, colors, typography, responsive layout, and details/confirmation modals. All implementation changes are frontend-only; backend source was inspected read-only.
- Confirmed existing POST/GET `/api/v1/admin/users` and GET/PUT/DELETE `/api/v1/admin/users/{id}` contracts. Requests use the existing central Axios client, Bearer interceptor, and centralized 401 handler. GET list uses the backend's zero-based `page`, `size`, `search`, `accountStatus`, `roleId`, and `departmentId`; responses have `content` and page metadata with no data wrapper.
- Create sends exactly the eleven documented fields from entered form values, including numeric role/department IDs, actual nullable department, and boolean forcePasswordChange. Passwords are confined to the form/request and cleared after successful creation. PUT sends exactly the eight supported identity/access fields; password fields and forcePasswordChange are not accepted by that contract and are omitted.
- Added validated positive safe-integer IDs before detail/update/delete requests, protected `/admin/users/create` alias and `/admin/users/:id` detail-modal route, loading/error/retry states, stale-list suppression during query changes, last-page recovery after deletion, and mutation feedback with refetch on returning to the list. Delete still requires confirmation and is locked against duplicate submissions. Failed deletion leaves records visible.
- Extended client validation to backend field lengths and password Unicode/72-byte limits. Known backend conflict and role errors map to field feedback; unexpected error text is not exposed. The backend returns only generic `VALIDATION_ERROR` for bean validation, not a field-error array, so those responses remain form-level errors.
- Contract gaps: no roles or departments lookup controller exists in the inspected backend. Removed unsupported department requests from connected screens. Creation can use department null; editing can retain the actual existing department ID or clear it. Table/filter use returned IDs, without inventing department names. Role options retain the existing V6 seeded configuration (1/2/3) and preserve an additional role returned on edit; a complete authoritative lookup requires a separately supplied API. Phone is nullable according to the actual DTO despite the spec's required-field example. Last login is not returned and displays an em dash. Page status counts use exact ACTIVE/INACTIVE values and are labeled as page-only counts.
- Added `tests/admin-users.test.cjs`: three passing Node test groups cover payload mapping/null/false behavior, field/password validation, actual service URLs/query parameters and auth interception with a mocked Axios adapter, invalid-ID rejection, centralized 401 handling, and safe API/field errors. Run with `node --test tests/admin-users.test.cjs`.
- Lint, TypeScript, production build, and Docker build passed; recreated only `admin-web` at localhost:3000. Existing bundle-size advisory remains non-blocking. Live authenticated CRUD verification is pending: the Review-pane app still redirected to login after sign-in confirmation. No supplied sample account was created during automated tests.

## 2026-10-01 - Enroll Student form

- Implemented the user-supplied screenshot of the Enroll Student modal (updated Figma link `70:11910`; live links selected only Page 1). Uses a centered 520px native dialog, divided header, required Student/Course/Section selectors, paired Semester/Academic Year selectors, and Confirm Enrollment/Cancel actions. Narrow screens stack the paired controls.
- Enroll Student now opens the form. Section is initially disabled and resets when Course changes. All five fields are validated; active/pending duplicates for the same student, course, semester, and academic year are rejected. Errors focus the first invalid enabled control. Added submit locking, retry-preserving errors, and dirty-close confirmation.
- Options derive from enrollment-local fixtures rather than assuming cross-directory relationships. Confirmation prepends an Active local demo record with today's local date, updates metrics/filter choices/export, preserves filters, clears selection, and returns to page 1 with explicit feedback if filters hide the new row. Status and duplicate policy are demo assumptions; eligibility, capacity, approval, and persistence still require service contracts.
- TypeScript, lint, production build, Docker build, and 12 validation/creation assertions passed. Recreated `admin-web` successfully at port 3000. Authenticated visual/interaction verification remains pending; local Review tab is at login.

## 2026-10-01 - Enrollments

- Implemented protected `/admin/enrollments` from live Figma node `67:10060` (2059 × 1091 dashboard). Exported and inspected the frame, preserving the existing approved shell and reusing local icons.
- Reproduced header actions, four cards, search and six filters, selectable ten-row table, student avatars, course/section/status treatments, and two-page pagination. Initial totals are 20 / 15 Active / 3 Pending / 2 Withdrawn or Dropped.
- Only ten enrollment records are visible in the supplied frame. Those were transcribed exactly; the ten page-2 records are explicitly named Demo Student records and identified as synthetic in the UI and CSV. Enrollment-local course codes, dates, and semester/year pairs are preserved without inventing relationships with other directories.
- Added combined filters, course-dependent section choices, page reset on filtering, empty results, individual and page selection with indeterminate state, and CSV export of selected records or all filtered records. CSV quotes values and escapes formula prefixes.
- Bulk Enroll, Enroll Student, and row actions explain that their forms/services are unavailable; no server mutations are simulated.
- TypeScript, lint, production build, Docker build, and 12 data/filter/CSV assertions passed. Recreated `admin-web` at port 3000. Existing bundle-size advisory is non-blocking. Authenticated browser verification remains pending because the local app redirected to login.

## 2026-10-01 - Course Sections

- Implemented `15-course-sections.md` at protected `/admin/sections`, linked from Academic Management. Inspected and exported live Figma frame `63:8330`; retained the approved existing shell and local icons.
- Preserved all 23 reference sections, lecturer titles, schedules, semester `1/2568`, and academic year `2024`. Derived totals match 23 sections, 21 Active, 2 Full, 1023 enrolled, and 1130 capacity.
- Added combined course/section search and Course, Semester, Year, Lecturer, Status filters; empty state; filtered footer totals; capacity meters; and explicit unavailable row-action feedback. Summary cards describe the full local directory.
- Added the 480px Create Section drawer, adjacent on desktop and modal below 1280px, with reproducible `?add=1` state. Includes required-field and duplicate validation, positive capacity, first-error focus, pending-submit protection, unsaved-change confirmation, and filter-preserving local creation with zero enrollment.
- Demo assumptions: Full is derived from enrollment reaching capacity unless Closed; Active excludes Full. Capacity bars are neutral below 80%, amber below 100%, and magenta at full. Blank capacity defaults to 50. Course and lecturer options use local fixtures; extra semester options and years 2025/2026 are demo choices. No inferred lecturer identity merging, scheduling conflict policy, or backend contract.
- TypeScript, lint, production build, Docker build, and 18 fixture/filter/validation/creation assertions passed. Recreated `admin-web` successfully at port 3000. Existing non-blocking bundle-size advisory remains. Authenticated interaction and rendered responsive comparison remain pending.

## 2026-10-01 - Add Course

- Implemented `14-add-courses.md` at protected `/admin/courses/new`, reached from Add Course. Inspected/exported live frame `63:7892` and its original back-arrow SVG. Reused local check/chevron assets, fonts, and the existing shell.
- Reproduced the full-width four-card layout, tinted icon/title headers, exact field ordering and placeholders, paired/full-width fields, initial Required type and Active status, dimmed dependent selects, and left-aligned Save Course/Cancel actions. Fields stack on narrow screens.
- Course catalog state now belongs to the parent route so creation can return to the list with the new record, original filters, success feedback, and updated summaries. Optional year/semester/program/capacity are genuinely unassigned when blank, rather than inventing defaults; new records start with zero sections. Table/filter/CSV handling supports unassigned values.
- Department choices merge the existing department fixtures and reference-specific course assignments. Program options use the existing explicitly demo relationships. Faculty/department changes clear incompatible selections. Demo year options are 1–6 and terms are 1/2568, 2/2568, Summer/2568; these are not asserted as backend policy.
- Added required and duplicate-code checks; nonnegative integer credits; optional positive integer capacity; known, non-self prerequisites with case-insensitive lookup and deduplication; dependent-ID validation; first-error focus; pending-submit protection; and dirty Cancel/Back confirmation. Form description, prerequisites, and capacity are retained in the local course record.
- Lint, TypeScript, production build, and 18 validation/creation/relationship/summary assertions passed. Docker frontend was rebuilt and recreated successfully. Production retains the existing non-blocking bundle-size advisory. Authenticated rendered checks remain pending: the browser redirected to login after the sign-in confirmation.

## 2026-10-01 - Courses

- Implemented `13-courses.md` at protected `/admin/courses`, with Academic Management navigation selection and the existing shared shell. Inspected/exported live node `63:6384` and saved its original upload/download SVGs locally; reused matching existing page icons.
- Added all 20 reference records, three catalog-wide summary cards, the exact heading/actions, eight-column table, Required/Active/Sem 1/2568 badges, and filtered result count. Current semester is explicitly configured as 1/2568 rather than inferred from the current date.
- Search and all six filters combine with AND. Faculty changes clear incompatible departments; faculty/department changes clear incompatible program filters. Empty results provide Clear filters. The async local adapter supports loading and retryable error UI without clearing filters.
- Program memberships are explicitly illustrative demo metadata, not Figma-derived relationships. The course-local department IDs preserve the reference's Computer Engineering under IT and Management under Business rather than modifying the existing Department/Program fixtures.
- Export prepares all filtered rows as UTF-8 CSV with quoted delimiters/newlines and spreadsheet-formula escaping. Add Course, Import Courses, and row actions explain that their approved flows/service contracts are unavailable.
- Eighteen assertions for reference totals, combined filters, dependency resets, explicit term counting, and CSV escaping passed, along with lint, TypeScript, production build, and Docker frontend build. The production build reports a non-blocking chunk-size advisory. Published by recreating only `admin-web` at localhost:3000. Authenticated interaction/responsive/visual comparison remains pending: the local-app Review tab was closed; only the Figma tab remains available.

## 2026-09-30 - Programs & Majors

- Implemented `12-programs&majors.md` at `/admin/programs`, with `/admin/programs?add=1` for the reference drawer-open state. Reused the authenticated academic shell and extended the shared Drawer to support 480px panels.
- Exported live `54:4923` after sign-in; the frame had been resized to 2058 × 1983. Transcribed all 25 records, including codes, department assignments, degree labels, durations, credits, and Public Relations as the sole inactive row. Sampled the eight badge background/foreground pairs from the exported image.
- Added combined search/faculty/department/degree/status filters, dependent department reset, accurate counts, and the specified Add Program fields. Department stays disabled until Faculty is selected. Paired controls stack on narrow screens.
- Local creation validates five required fields, case-insensitive duplicate codes, faculty/department compatibility, configured durations, and optional nonnegative whole-number credits. Empty credits remain null; zero is preserved. Filters survive creation and hidden new records are announced. Duration options 1–6 and lookup eligibility are prototype choices; row actions explicitly remain unavailable.
- Lint, TypeScript, production/Docker builds, and 22 data/filter/validation assertions passed. Published by rebuilding/recreating only `admin-web` at port 3000. The user chose to finish with build checks; authenticated interaction/responsive/visual comparison remains pending.

## 2026-09-30 - Departments

- Implemented `11-departments.md` at protected `/admin/departments`, with `/admin/departments?add=1` for the open drawer. Connected Academic Management → Departments and the header context label to the existing shell.
- Inspected and exported the user's live node `42:3495` (1459 × 867 dashboard with adjacent 460px drawer). It clips the directory vertically; the Markdown references the taller `42:2512`. Kept all 18 specified rows and natural page scrolling, with initial count `Showing 18 of 18 departments`.
- Search, faculty, and status filters combine with AND. Creation preserves these filters and announces when they hide the newly added record. No extra rows were invented to reconcile the Faculties screen's separate 20-department fixture total.
- Added a reusable native-dialog Drawer: adjacent and nonmodal at 1280px+, modal below that width, independently scrollable content, persistent footer, focus handling, Escape, and dirty-close confirmation. Retained the approved shell and mobile sidebar breakpoint.
- Per the latest user correction, Faculty is one editable combobox with `Search or select a faculty…`. Options filter by English/Thai names and code; selecting a result displays its name in the same field. There is no second search box. Supports keyboard highlighting/selection, Escape-before-drawer dismissal, outside dismissal, selected IDs, loading/retry/empty states, and a bounded top-layer popover positioned above the input when needed to avoid clipping.
- Reused the original exported plus/search/dots/close/check SVGs from Faculties; exported both distinct 10 × 6 department dropdown arrows from the new live frame. Uses existing local fonts including Noto Sans Thai.
- Faculty options come from an asynchronous, explicitly local demo adapter offering all seven faculty fixtures. Production eligibility and API contracts are unresolved. Creation validates required fields, known faculty IDs, and university-wide case-insensitive duplicate codes (a demo policy); new records have zero program/course/student counts and reset on leaving/reloading. Row actions explicitly state unavailable integration.
- Lint, TypeScript, production/Docker builds and 17 data/validation assertions passed. Re-ran lint, TypeScript, production/Docker builds after the final single-input adjustment and deployed the update by recreating only `admin-web` on port 3000. Authenticated UI, keyboard, failure-state, and rendered visual checks remain pending: the app Review tab is at login.

## 2026-09-29 - Add Admin User and Faculties

### Add Admin User

- Implemented `09-add-admin-user.md` at `/admin/users/new`, reached from the existing Add Admin User action. Inspected and exported the user's live Figma frame `42:4478` (1459 × 1148); the specification references its nested `42:4481` frame.
- Reused the existing authenticated shell and fonts. Added the left-aligned 900px three-card form, responsive field grids, independent password visibility, checked force-change option, required/email/password/duplicate validation, field-linked errors, first-error focus, and dirty Cancel/Back confirmation.
- Exported original back, eye, check, and user-plus SVGs to `public/assets/figma/admin-*.svg`. Existing shared shell icons and expansion behavior remain the previously approved implementation.
- User Management now owns in-memory records across its list/new child routes. Successful creation adds only non-sensitive table fields. Department/role/status choices are explicitly mock data; passwords and confirmation are cleared and never placed in list data or browser storage. No account API or first-login enforcement exists.
- Lint, TypeScript, production/Docker builds, and validation/data-boundary assertions passed. Deployed to port 3000. Authenticated browser verification remains pending: the Review tab is at login and the user moved on to Faculties without answering the sign-in request.

### Faculties

- Implemented `10-faculties.md` at `/admin/faculties`; `/admin/faculties?add=1` reproduces the open drawer state. Inspected and exported live frame `42:2`, including its adjacent drawer.
- Added seven exact reference records with English/Thai names, codes, counts, badges, search across all names/codes, empty results, and complete-directory derived metrics of 7 / 6 / 20.
- The 460px drawer reserves space beside the shell at widths of 1280px and up. At narrower widths it uses native modal-dialog behavior; below 460px it fills the available width. Its body scrolls independently between the header and footer. The existing shell retains its 768px mobile navigation breakpoint.
- Creation is local-only with zero department/student counts, required-field and case-insensitive duplicate-code checks, pending-submit protection, status radio controls, focus handling, dirty-close confirmation, and success feedback. Row actions explicitly explain that editing/deletion/status changes are unavailable.
- Exported five original page/drawer SVGs to `public/assets/figma/faculty-*.svg`. Added the locally bundled Noto Sans Thai 400 font for Thai text; reused the approved shell/logo/fonts.
- Lint, TypeScript, production/Docker builds, and 12 assertions covering fixture totals, English/Thai search, empty results, required/duplicate validation, Unicode preservation, and local creation passed. Rebuilt and recreated only `admin-web` on port 3000. The user chose to finish with build checks; authenticated interaction, responsive rendering, and visual comparison checks remain pending.

## 2026-09-29 - Class Timetable

- Implemented `08-Timetable.md` at protected `/admin/timetable`, with the existing layout, navigation, authentication, and shared modal. The Markdown ends at the view-toggle example; the remaining calendar content was based on the exported 2058 × 1073 Figma frame `34:3999` after user sign-in.
- Added Monday–Saturday Calendar and List views sharing 29 reference-based schedules, semester/year and dependent faculty/department/course filters, faculty colors, schedule details, and a local Add Class Schedule form. Department assignments are demo metadata; ellipses preserve clipped reference values.
- New schedules validate required fields, time boundaries, minimum one-hour duration, and overlapping rooms, instructors, or course sections. Additions are local page state and reset on leaving the page.
- Schedule Conflicts preserves the reference count of four and explicitly states that conflict records are unavailable. The reference count is not represented as computed backend data.
- Lint, TypeScript, production build, nine utility checks covering layout/filter/validation behavior, and Docker frontend build passed. Published by rebuilding and recreating only `admin-web` at localhost:3000.
- Authenticated rendering, responsive browser checks, and rendered visual comparison remain pending: opening the protected route redirected to login. The user chose to finish with build checks. Figma export inspection is complete, but does not constitute rendered browser verification.

## 2026-09-29 - Students Management

### Implementation and scope

- Implemented `07-students.md` at the protected `/admin/students` route, reusing `AdminLayout`, Sidebar active-link styling, TopNav, Modal, Badge, existing fonts, and Lucide icons. Added reusable Pagination and typed student fixtures/filter/validation/export helpers.
- Added the specified heading/actions, four dataset-wide metrics (24 / 20 / 3 / 4 initially), ten verified first-page records, faculty/department and year/semester hierarchy, colored statuses, and ten-row pagination.
- Search matches ID/name/email; six filters combine with AND and reset pagination. Faculty and department changes clear incompatible dependent filters. Global search remains independent.
- Per the user's subsequent screenshot, search and six filters share one compact desktop row at 1440px as well as the wide reference size. Narrower layouts wrap without shrinking text or introducing horizontal page scrolling; the table owns its horizontal scrolling.
- Add Student validates required fields, email format, duplicate IDs/emails, supported statuses/semesters, years, and academic combinations. Successful additions exist only in local page state and clearly disclose that no server account was created. Row action buttons open read-only student details using the shared accessible dialog.
- Export Students downloads all filtered rows, not just the current page, as `students.csv` with quoted fields and spreadsheet formula escaping.
- Import Students opens an explicit unavailable state: this repository defines neither an agreed import schema nor an import endpoint. No schema/API/delete/permission operations were invented.
- Fourteen additional records are explicitly named `Demo Student` with `DEMO-STU-*` IDs and example.com emails. They are synthetic, not Figma-extracted. `newThisSemester` is an explicit demo flag on three synthetic records, not an inference from academic year/semester. Creation forms allow this flag to be set explicitly.
- The reference's blank university-image slot is superseded by the previously approved `public/assets/rsulogo.png`. The existing shared logo, expanded sidebar, header styling, Dashboard, and Admin Users layout remain intact.

### Verification

- `npm run lint`, `npx tsc --noEmit`, `npm run build`, and the Docker frontend production build passed. Recreated only `admin-web`, keeping the canonical app on port 3000.
- Verified the actual route after normal user sign-in: Students active link, ten IDs in source order, initial range `Showing 1–10 of 24 students`, summary values, each search field, all six filters, dependent-selection resets, combined filters, zero-results range, page-three boundary, required-field and duplicate validation, local addition, summary updates, dialog closure/focus restoration, and export of 14 filtered demo rows across pagination.
- Checked actual protected rendering at controlled viewport widths 2059, 1440, 1024, and 390. No page overflow at those sizes; four/two/one summary columns; desktop filter row stays inline; narrow tables scroll within their container. Temporary responsive-check frames were removed afterward; the final app contains one main and one student table.
- Figma authentication succeeded, but node `28:2369` repeatedly redirected to Page 1 without selecting a Students frame. Styling follows the detailed recorded measurements in the spec and the user's search/filter screenshot. An exact live-frame visual comparison remains pending an accessible Students node or reference export.

## 2026-09-27 - User Management / Admin Users

### Implementation

- Read `06-user-management.md` and inspected the existing React/TypeScript components, routes, authentication, styles, and assets before implementation.
- After the user signed in to Figma, inspected node `22:1698` and exported its 1460 × 1066 PNG. Followed the visible Admin Users title/subtitle, Export and Add Admin User labels, filter bar, eight table columns, visible account fixtures, role/status badges, and pagination.
- The user's subsequent screenshot overrides the original centered tabs: Admin Users / Roles & Permissions is left-aligned below the page description.
- Added the protected `/admin/users` route. Reused `AdminLayout`, Sidebar link/active styles, existing TopNav, shared `Badge` and `Panel`, local logo/fonts, and Lucide icons. The header's existing location control changes its label/icon for User Management; its styling is unchanged. Dashboard source and shared shell styling were not modified for this feature.
- Admin Users behavior is implemented in TypeScript components with separate typed fixtures and utility functions. A small JSX route adapter follows the existing JavaScript authentication-hook pattern.
- Added immediate search by name/email/role/employee ID, combined role/status/department filters, eight-row pagination, clear empty states, CSV export of the displayed page, and row-detail dialogs.
- Added a reusable native-dialog Modal and Add Admin form with required fields, valid-email checks, duplicate email/employee-ID checks, keyboard focus containment/restoration, Escape dismissal, and explicit frontend-only feedback.
- Admin changes are in-memory demo data and reset when the page is reopened. The first eight rows match the visible reference; four clearly named demo accounts support its 12-account/two-page count. Creation dates and second-page records are fixtures, not claimed Figma/backend data.
- Roles & Permissions remains visible and displays exactly `Not available right now`. No permission functionality or management API endpoints were introduced.

### Verification

- `npm run lint`, `npx tsc --noEmit`, and `npm run build` passed.
- Rebuilt and ran only the existing Docker frontend on port 3000, preserving backend/data services and authentication.
- After normal user sign-in, verified the actual protected route, User Management active link, eight initial rows, search by each supported field, no-result state, page two, filter-induced page reset, combined filters, unavailable Roles & Permissions state, modal required/duplicate validation, successful local addition, focus restoration, and downloaded CSV contents (header plus eight displayed records).
- Compared the actual authenticated page at a controlled 1460 × 1066 viewport against the exported reference. Also checked 1024, 768, and 390 px widths: the table scrolls horizontally inside its panel with no page overflow. At a 320 px viewport with a non-overlay scrollbar, the existing global 320 px minimum page width leaves scrollbar-width overflow; shared global styling was preserved per the request.
- Temporary responsive checks loaded the actual protected route with the real session, not a replacement component or mocked authentication, and were removed afterward.

## 2026-09-25 - Sidebar Logo Asset

- Updated the sidebar to use the supplied `public/assets/rsulogo.png` via `/assets/rsulogo.png`.
- Preserved the approximately 103 × 40 px logo slot with proportional `object-contain` sizing and prevented flex shrinking.

## 2026-09-25 - Local Runtime Investigation and Updated Deployment

- Port 3000 was served by the Docker `smart-university-admin-web-1` container (Nginx, host 3000 → container 80), built before the dashboard changes. Its old bundle `index-Dpi3r5Io.js` contained the signed-in-email dashboard placeholder.
- Docker Compose is owned by `SeniorProject/backend/senior-project-smart-ai-web-backend/compose.yaml`; its resolved frontend build context is `SeniorProject/frontend/senior-project-smart-ai-admin-panel`, the current checkout containing the updated components.
- Port 3001 was Vite PID 19904, launched from this same frontend checkout. Its API base was `http://localhost:8080`, but the running backend only allowed CORS origin `http://localhost:3000`. A preflight from port 3001 returned HTTP 403, explaining the login connection error.
- Port 3002 had no active listener/process during investigation. Its previous working directory cannot be established from the current process list.
- Rebuilt `admin-web` from the current checkout and ran `docker compose up -d --no-deps admin-web` in the backend Compose directory. Only the frontend container was replaced. Backend, Postgres, Redis, and other processes were left running; existing source/configuration changes were preserved.
- Canonical local URL: **http://localhost:3000/admin/dashboard**. The new served bundle is `index-DNi8eM_-.js`; the frontend container is healthy. Docker build uses `VITE_API_BASE_URL=http://localhost:8080` from the existing resolved configuration.
- Verified CORS preflight from port 3000 returns 200 with the correct allowed origin. A browser POST with an empty login payload reaches the real API and returns its expected 400 validation response, rather than a connection failure.
- The user then signed in normally in the Review pane. Verified the actual authenticated `/admin/dashboard` DOM: one sidebar, one header, one dashboard main, six expanded-group controls, 23 submenu items, six statistics, five quick actions, five events, five activities, four classes, three announcements, and footer. Old placeholder absent; scrolling preserves the route; no horizontal overflow at the current preview viewport. No authentication bypass or mocked session was used.
- This confirms the deployed version and authenticated rendering, not a pixel comparison with Figma. Figma visual comparison remains pending reference access.

---

## 2026-09-25 - Updated Dashboard Sidebar

### Changes and decisions

- Added reusable typed `AdminLayout`, `Sidebar`, and navigation data using the installed React Router, Lucide icons, local university logo, and Plus Jakarta Sans font.
- This checkout had no existing sidebar and only a minimal dashboard. Wrapped its existing content and Logout action in the new shell, retaining the single `/admin/dashboard` route.
- Included all 11 top-level entries, six independently expanded groups, and 23 exact submenu labels from `05-dashboard.md`, with indented guide lines and bullets.
- Navigation scrolls independently within a viewport-height sidebar; branding and the administrator profile remain anchored. Added compact mode and a mobile drawer with focus containment, Escape/backdrop dismissal, and focus restoration.
- Missing management destinations display explicit unavailable feedback instead of broken links. Dashboard is the only integrated destination.
- Added TypeScript checking for new typed files and ESLint TypeScript support using already-installed dependencies. Loaded the existing font package's medium weight and put the form font reset in Tailwind's base layer so navigation typography utilities apply.
- Figma returned HTTP 403; used the updated specification's documented node measurements and labels. Exact live Figma/icon comparison remains unverified.

### Validation

- `npm run lint`, `npm run build`, and `npx tsc --noEmit` passed.
- Browser checks used the real sidebar/layout in an isolated React Router harness (without changing application authentication), at 1440×900, 1024×768, 768×600, 390×844, 320×480, and 1280×420.
- Verified 11 top-level items, 23 children, six initially open groups, independent collapse, hidden collapsed panels, preserved main scroll position, compact width, no horizontal overflow, reachable Audit Logs, anchored profile, mobile Escape/focus restoration, and forward/reverse focus containment.

---

## 2026-09-25 - Complete Protected Dashboard

### Changes and decisions

- Removed the browser-only sidebar verification harness by reloading the preview. Its “Dashboard scroll verification” text was never part of application source; the underlying dashboard was still a minimal placeholder.
- Inspected `AppRoutes`, `ProtectedRoute`, `AuthProvider`, login navigation, and the API client. `/admin/dashboard` is protected and redirects unauthenticated visitors to `/login`. Authentication was not bypassed or mocked.
- Replaced the minimal dashboard content with the complete single-page composition from `05-dashboard.md`: top navigation, greeting/date, six statistics, five quick actions, usage chart/five events, five activities/four classes, three announcements, and footer.
- Added typed sample data, reusable panel/badge/action components, and a responsive SVG chart with accessible text. Reused the installed icon/font packages, university logo, sidebar, router, and real logout flow. Existing login-specific Button/Input components have fixed dimensions unsuitable for compact dashboard controls.
- Kept one dashboard route and document scroll owner. Retained the independently scrollable sidebar and bottom profile. Dashboard panels stack at smaller widths; statistics and announcements use responsive grids.
- Search filters displayed sample course/room/announcement data. Notifications disclose the absent live feed. Missing workflows display explicit unavailable feedback, including the shared Create Announcement handler. Account menu retains real Logout.
- Usage values `[18, 12, 9, 35, 130, 210, 155, 245, 190, 145, 100, 55]` are approximate demo values based on the written curve description; they are not Figma-extracted or live analytics. Accent colors and geometry beyond the documented spec are provisional pending design access.

### Project checks

- `npm run lint`, `npm run build`, and `npx tsc --noEmit` passed.
- Source search confirms no verification placeholder or alternate DashboardScreen components remain.

### Visual verification — pending, not passed

- No Figma tools or MCP resources were exposed in the session; direct design access returned HTTP 403. Requested screenshots of sidebar `12:666`, top `6:936`, and lower `9:2`.
- Opened the actual `/admin/dashboard` URL. The connected preview redirected to `/login`; after the user reported signing in, the connected tab still showed `/login` after refresh. Requested login in that specific Review-pane browser session.
- The authenticated dashboard's top/lower screenshots, same-size/100%-zoom Figma comparison, and rendered responsive checks are blocked pending authenticated preview access and reference screenshots. Earlier sidebar-harness checks do not constitute full-dashboard visual verification.

---

## 2026-09-22 - Docker Setup

### Changes

- Added multi-stage `Dockerfile` using Node.js 22 Alpine for the frontend build.
- Added Nginx Alpine as the production runtime.
- Initially added a frontend-local `compose.yaml` for the `admin-web` service.
- Added `nginx.conf` with React SPA fallback routing.
- Added `.dockerignore` to reduce the Docker build context.
- Updated `.gitignore` for dependencies, build output, environment files, logs, caches, editors, and OS files.
- Updated `README.md` with Docker usage.

### Decisions

- The frontend production container serves the Vite build through Nginx rather than running the Vite development server.
- The frontend container exposes port `3000` by default.
- `VITE_API_BASE_URL` is supplied at image build time because Vite embeds environment variables into the browser bundle.

### Validation

- `npm run build` passed.
- `npm run lint` passed.
- `docker compose config` passed.
- Docker image build passed.
- Nginx configuration test passed.
- Docker health check and HTTP response test passed.

---

## 2026-09-22 - Environment Configuration

### Changes

- Added `.env` with local development defaults.
- Added `.env.example` with documented environment variables.
- Updated `README.md` with environment variable documentation.

### Decisions

- `VITE_API_BASE_URL` defaults to `http://localhost:8080`.
- `FRONTEND_PORT` defaults to `3000`.
- `.env` remains ignored by Git.
- `.env.example` remains trackable because it contains no secrets.

### Validation

- `npm run build` passed.
- `docker compose config` passed.

---

## 2026-09-22 - MCP Setup

### Changes

- Added `.vscode/mcp.json` for the remote Figma MCP server.
- Added `opencode.jsonc` for OpenCode project instructions and Figma MCP configuration.
- Updated `.gitignore` so `.vscode/mcp.json` can be committed.

### Decisions

- Figma remote MCP uses `https://mcp.figma.com/mcp`.
- No Figma token, password, or credential is stored in project configuration.
- OpenCode uses the current valid schema format: `mcp.figma`, not the older `mcp.servers.figma` shape.
- VS Code uses its required `servers.figma` shape.

### Current Status

- OpenCode detects the Figma MCP server.
- Figma OAuth authentication is blocked externally because Figma reports that the OpenCode OAuth client ID does not exist.
- No project-side credential or endpoint failure was found.

### Validation

- `.vscode/mcp.json` parsed as valid JSON.
- `opencode mcp list` detected `figma` and reported `needs authentication`.

---

## 2026-09-22 - Login Screen

### Changes

- Implemented responsive `/login` page.
- Added login branding, login card, form validation, password visibility toggle, Remember Me UI, forgot-password message state, security indicators, staff notice, and footer.
- Added reusable `Input` and `Button` UI components.
- Added local Rangsit University logo usage from `public/assets/rsulogo.png`.
- Added local Inter and Plus Jakarta Sans font loading.
- Added Axios API client and authentication service.
- Added React Router.
- Set Vite development server port to `3000`.
- Vertically centered the full login content column in the viewport.

### Decisions

- The login form submits through a real `<form>` and `onSubmit`.
- `rememberMe` is not sent to the backend because the backend login request contract only supports `email` and `password`.
- Credentials are not logged or persisted.
- Figma fixed-artboard dimensions were converted to responsive layout using viewport sizing, max width, flexbox, and responsive spacing.
- The official RSU logo is served locally from `public/assets/rsulogo.png` instead of a temporary remote URL.

### Validation

- `npm run lint` passed.
- `npm run build` passed.
- Docker production build passed.
- Direct `/login` SPA route test passed.
- Nginx fallback routing passed.

---

## 2026-09-22 - Frontend Authentication

### Changes

- Added centralized `AuthContext` and `useAuth` hook.
- Added centralized `tokenStorage` utility.
- Added login, refresh, and logout methods to `authService`.
- Added Axios request interceptor for `Authorization: Bearer <accessToken>`.
- Added centralized Axios 401 response handling.
- Added authentication initialization using the backend refresh endpoint.
- Added `ProtectedRoute` for `/admin/*`.
- Added `AppRoutes` and root redirect behavior.
- Added temporary `DashboardPage` with authenticated user display and logout.
- Connected successful login to `/admin/dashboard`.
- Connected authenticated `/login` access to `/admin/dashboard`.
- Connected unauthenticated dashboard access to `/login`.
- Removed the obsolete duplicate `authSession.js` helper.

### Decisions

- Authentication state is managed by React Context.
- Only authentication tokens are persisted; raw passwords are never persisted.
- Remember Me uses `localStorage`; non-Remember Me sessions use `sessionStorage`.
- Access and refresh tokens are also mirrored in memory for centralized interceptor access.
- Authentication restoration uses `POST /api/v1/admin/auth/refresh` when stored tokens exist.
- Logout calls `POST /api/v1/admin/auth/logout` and clears frontend authentication state in a `finally` block.
- A 401 response clears frontend authentication state centrally without coupling Axios directly to React Router.
- The dashboard remains temporary because the complete Dashboard module has its own future specification.

### Validation

- `npm run lint` passed.
- `npm run build` passed.
- Docker production build passed.
- Direct `/login` SPA route test passed.
- Direct `/admin/dashboard` SPA route test passed.
- Backend login endpoint returned the expected `401` for invalid credentials.

---

## 2026-09-22 - Unified Docker Compose Project

### Changes

- Moved the `admin-web` service definition into `backend/seniorproject/compose.yaml` under project name `smart-university`.
- Replaced the separate frontend Compose project with a frontend `compose.yaml` that includes the backend Compose file.
- The frontend Compose entry overrides only the `admin-web` build context so it uses this frontend folder.
- The frontend Compose entry explicitly loads `backend/seniorproject/.env` for the included backend services.
- Added `FRONTEND_PORT` and `VITE_API_BASE_URL` to the backend `.env` and `.env.example` files.
- Updated frontend and backend README Docker instructions.

### Decisions

- Both commands operate on one Compose project named `smart-university`:
  - `docker compose up -d --build` from `frontend/smart-ai-admin-web`
  - `docker compose up -d --build` from `backend/seniorproject`
- Docker containers are grouped under `smart-university` as `postgres-1`, `redis-1`, `backend-1`, and `admin-web-1`.
- The backend Compose file remains the source of truth for PostgreSQL, Redis, and backend settings.
- The frontend Compose file exists so running Compose from the frontend folder still manages the complete same project without orphan warnings.
- `admin-web` starts after `backend`.
- `VITE_API_BASE_URL` remains `http://localhost:8080` because browser JavaScript runs on the host and cannot resolve Docker's internal `backend` hostname.
- Backend database, Redis, JWT, and private-key environment variables remain in the backend service only and are not passed to the frontend.

### Validation

- Unified `docker compose config` passed from the frontend folder.
- `docker compose config --services` showed `postgres`, `redis`, `backend`, and `admin-web`.
- `docker compose up -d --build` from the frontend folder built and started the complete stack under `smart-university` without orphan warnings.
- `docker compose ps` showed all four services under the `smart-university` project.
- Frontend HTTP route check passed.
- Backend login endpoint returned the expected `401` for invalid credentials.

## 2026-11-10 - Enrollment due date on the timetable; enroll only into scheduled sections

Backend spec `44-enrollment-timetable-and-due-date.md` (decision D62, Flyway V47). Requested by Hsu.

### Changes

- **Timetable schedule form:** new optional **Enrollment Due Date** next to Effective From / Effective To. It is sent as `enrollmentDueDate` and may not be after Effective From (checked in the form and by the backend, `TIMETABLE_INVALID_ENROLLMENT_DUE_DATE`). Empty means no deadline. The class details drawer shows "Enroll by <date>".
- **Enrollment form section picker:** asks for `status=ACTIVE&scheduled=true`, so only sections with a published timetable are offered, and shows "enroll by <date>" or "closed <date>" in the option label.
- **Messages** for the new refusals `COURSE_SECTION_NOT_IN_TIMETABLE` and `ENROLLMENT_DUE_DATE_PASSED`.

### Validation

- `tsc --noEmit`, `eslint src`, `vite build` and `node --test tests/*.cjs` (78 passed, with new due-date cases in `tests/timetable-utils.test.cjs`). Not clicked through in a browser.
